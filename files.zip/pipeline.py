# pipeline.py — Milho Trader v1.0
# Orquestrador principal — lê todos os CSVs e gera dados_milho.json
# Uso: python pipeline.py [pasta_dados] [pasta_saida]

import json
import os
import sys
from datetime import datetime

from leitor_csv    import ler_csv, ultimo_valor
from ccm_dados     import analisar_ccmfut, analisar_curva_vencimentos, calcular_sizing
from convergencia  import analisar_convergencia
from cambio_macro  import analisar_macro_completo


# ── CONFIGURAÇÕES ─────────────────────────────────────────────────────────────
PASTA_DADOS  = r'C:\Projetos Phyton\Milho'
PASTA_SAIDA  = r'C:\Projetos Phyton\Milho'
ARQUIVO_JSON = 'dados_milho.json'

# OI de opções — preencher manualmente ou integrar fonte futura
OI_OPCOES_DEFAULT = {
    'call_wall': None,
    'put_wall':  None,
    'max_pain':  None,
    'fonte':     'manual',
}

# Fundamentos — preencher manualmente (CONAB/WASDE mais recentes)
FUNDAMENTOS_DEFAULT = {
    'safra_br_estimativa_mt': 140.5,
    'colheita_safrinha_pct':  None,
    'estoques_globais_mt':    281.2,
    'vies_fundamental':       'BAIXISTA',
    'fonte':                  'CONAB/WASDE Jun-2026',
}


# ── PIPELINE PRINCIPAL ────────────────────────────────────────────────────────

def rodar_pipeline(pasta_dados: str, pasta_saida: str) -> dict:
    """
    Executa todas as etapas do pipeline e retorna o JSON completo.
    """
    log = []
    erros = []

    def ok(msg):
        log.append(f'✅ {msg}')
        print(f'✅ {msg}')

    def err(msg):
        erros.append(f'❌ {msg}')
        print(f'❌ {msg}')

    print('=' * 60)
    print(f'MILHO TRADER — PIPELINE v1.0')
    print(f'Data/hora: {datetime.now().strftime("%d/%m/%Y %H:%M:%S")}')
    print(f'Pasta dados: {pasta_dados}')
    print('=' * 60)

    # ── ETAPA 1: CCM FUTURO ───────────────────────────────────────────────────
    dados_ccm = None
    try:
        dados_ccm = analisar_ccmfut(pasta_dados)
        ok(f'CCMFUT | Preço: R$ {dados_ccm["ultimo_preco"]}/sc | '
           f'EMA9/20: {dados_ccm["sinal_ema920"]} | '
           f'9.1: {dados_ccm["sinal_91"]}')
    except Exception as e:
        err(f'CCMFUT falhou: {e}')
        dados_ccm = _ccm_vazio()

    # ── ETAPA 2: CURVA DE VENCIMENTOS ─────────────────────────────────────────
    curva = {'contratos': [], 'estrutura': 'N/A', 'total_vencimentos': 0}
    try:
        curva = analisar_curva_vencimentos(pasta_dados)
        ok(f'Curva | {curva["total_vencimentos"]} contratos | {curva["estrutura"]}')
    except Exception as e:
        err(f'Curva de vencimentos falhou: {e}')

    # ── ETAPA 3: CONVERGÊNCIA (RTCNI) ─────────────────────────────────────────
    convergencia = {}
    try:
        convergencia = analisar_convergencia(pasta_dados, dados_ccm['ultimo_preco'])
        alerta_str = '⚠️ ALERTA' if convergencia.get('alerta_convergencia') else 'normal'
        ok(f'RTCNI | Físico: R$ {convergencia.get("rtcni_preco")}/sc | '
           f'Spread: R$ {convergencia.get("spread_futuro_fisico")}/sc | '
           f'Z={convergencia.get("spread_zscore")}σ | {alerta_str}')
    except Exception as e:
        err(f'Convergência falhou: {e}')

    # ── ETAPA 4: CÂMBIO, DI, ZC E BRENT ──────────────────────────────────────
    macro_completo = {}
    try:
        preco_fisico = convergencia.get('rtcni_preco') or 0.0
        macro_completo = analisar_macro_completo(
            pasta_dados,
            dados_ccm['ultimo_preco'],
            preco_fisico,
        )
        cam = macro_completo['cambio']
        zc  = macro_completo['zc_cme']
        ok(f'Câmbio | USDBRL: {cam.get("wdofut_usdbrl")} | Diagnóstico: {cam.get("diagnostico")}')
        ok(f'ZC CME | {zc.get("preco_cents_bu")} c/bu | Fonte: {macro_completo.get("fonte_zc")}')
    except Exception as e:
        err(f'Macro falhou: {e}')

    # ── ETAPA 5: SIZING ───────────────────────────────────────────────────────
    sizing = calcular_sizing(dados_ccm['ultimo_preco'])
    risco_por_contrato = round(dados_ccm.get('stop_atr15_dist', 0) * 450, 2)

    # ── MONTA JSON ────────────────────────────────────────────────────────────
    cam  = macro_completo.get('cambio', {})
    di   = macro_completo.get('carrego', {})
    zc   = macro_completo.get('zc_cme', {})
    mac  = macro_completo.get('macro', {})

    payload = {
        'meta': {
            'versao':          '1.0',
            'gerado_em':       datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
            'pasta_dados':     pasta_dados,
            'erros':           erros,
            'log':             log,
        },
        'data_referencia': dados_ccm.get('data_ultimo', datetime.now().strftime('%d/%m/%Y')),

        # CCM — análise técnica
        'ccm': {
            'ultimo_preco':        dados_ccm['ultimo_preco'],
            'variacao_semanal_pct': dados_ccm['variacao_semanal_pct'],
            'vencimento_ativo':    dados_ccm['vencimento_ativo'],
            'ema9':                dados_ccm['ema9'],
            'ema20':               dados_ccm['ema20'],
            'sinal_ema920':        dados_ccm['sinal_ema920'],
            'ema9_slope':          dados_ccm['ema9_slope'],
            'sinal_91':            dados_ccm['sinal_91'],
            'atr14':               dados_ccm['atr14'],
            'stop_atr15':          dados_ccm['stop_atr15'],
            'stop_atr15_dist':     dados_ccm['stop_atr15_dist'],
            'alvo_rr2_dist':       dados_ccm['alvo_rr2_dist'],
            'risco_por_contrato':  risco_por_contrato,
            'volume_medio':        dados_ccm['volume_medio'],
            'suporte':             dados_ccm['suporte'],
            'resistencia':         dados_ccm['resistencia'],
        },

        # Curva de vencimentos
        'curva_vencimentos':  curva['contratos'],
        'estrutura_curva':    curva['estrutura'],

        # Convergência futuro×físico
        'convergencia': convergencia,

        # Custo de carrego (DI)
        'carrego': di,

        # Câmbio
        'cambio': cam,

        # ZC CME
        'zc_cme': zc,

        # Macro
        'macro': mac,

        # Fundamentos (manual — atualizar conforme CONAB/WASDE)
        'fundamentos': FUNDAMENTOS_DEFAULT,

        # OI Opções (manual ou fonte futura)
        'oi_opcoes': OI_OPCOES_DEFAULT,

        # Sizing por perfil
        'sizing': {
            **sizing,
            'risco_por_contrato': risco_por_contrato,
        },

        # Destaque da semana (preencher manualmente antes de gerar relatório)
        'destaque_semana': 'Preencher manualmente: tema de destaque desta semana.',
    }

    # ── SALVA JSON ────────────────────────────────────────────────────────────
    path_json = os.path.join(pasta_saida, ARQUIVO_JSON)
    with open(path_json, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, default=str)

    print()
    print('=' * 60)
    if erros:
        print(f'⚠️  Pipeline concluído com {len(erros)} erro(s)')
        for e in erros:
            print(f'   {e}')
    else:
        print('✅ Pipeline concluído sem erros')
    print(f'📄 JSON salvo em: {path_json}')
    print('=' * 60)

    return payload


# ── FUNÇÕES DE FALLBACK ───────────────────────────────────────────────────────

def _ccm_vazio() -> dict:
    return {
        'ultimo_preco': 0.0, 'variacao_semanal_pct': None,
        'vencimento_ativo': 'N/A', 'ema9': 0.0, 'ema20': 0.0,
        'sinal_ema920': 'N/A', 'ema9_slope': 0.0, 'sinal_91': 'N/A',
        'atr14': 0.0, 'stop_atr15': 0.0, 'stop_atr15_dist': 0.0,
        'alvo_rr2_dist': 0.0, 'volume_medio': 0,
        'suporte': 0.0, 'resistencia': 0.0, 'data_ultimo': 'N/A',
    }


# ── ENTRY POINT ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    pasta_d = sys.argv[1] if len(sys.argv) > 1 else PASTA_DADOS
    pasta_s = sys.argv[2] if len(sys.argv) > 2 else PASTA_SAIDA
    rodar_pipeline(pasta_d, pasta_s)
